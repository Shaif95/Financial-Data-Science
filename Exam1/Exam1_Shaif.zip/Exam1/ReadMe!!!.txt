ReadMe :

1.  code should run for all the Notebooks.

2. CSNE, SVM Grid search might take really long time. Transformer, LSTM training is also time consuming,
but you can decrease the number of epochs.

3. For the Deep Learning notebook, I recommend running on Colab. I have used my own Python Environment, 
so it might run into error on your base python.

4. On the notebook named "all" , don't run the deep learning code at the far end. 
It might cause system problems. Deep learning code is given on a separate notebook instead.

